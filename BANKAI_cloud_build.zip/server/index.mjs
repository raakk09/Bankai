import express from "express";
import OpenAI from "openai";

const app = express();
app.use(express.json());

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const BANKAI_INSTRUCTIONS = `
You are BANKAI, a general-purpose AI assistant.
Your goal is maximum helpfulness: understand the user's intent, answer directly,
reason carefully, use tools when needed, and keep the conversation useful.
For current facts, use web search when available. Never invent sources or facts.
Be natural, concise by default, and adapt to the user's language.
Do not expose hidden chain-of-thought; provide conclusions and useful explanations.
For unsafe requests, do not provide harmful actionable instructions; instead provide
the maximum safe, practical help and continue the conversation.
`;

app.post("/chat", async (req,res)=>{
  try {
    const message = String(req.body?.message ?? "").trim();
    if (!message) return res.status(400).json({error:"message required"});
    const response = await client.responses.create({
      model: process.env.BANKAI_MODEL || "gpt-5.6-luna",
      instructions: BANKAI_INSTRUCTIONS,
      tools: [{ type: "web_search" }],
      input: message
    });
    res.json({answer: response.output_text});
  } catch (e) {
    console.error(e);
    res.status(500).json({error:"BANKAI backend error"});
  }
});

app.listen(3000, ()=>console.log("BANKAI server listening on :3000"));
