# BANKAI 0.2

This build adds the first real AI backend bridge.

## Architecture
Android app -> BANKAI backend -> AI Responses API -> web search/tool layer -> answer.

## Run backend
1. Install Node.js.
2. `cd server`
3. `npm install`
4. Set `OPENAI_API_KEY` as an environment variable. Never put the key in the Android app.
5. `node index.mjs`

For an Android emulator, the app calls `http://10.0.2.2:3000`.
For a physical phone, replace that address with the computer's LAN IP and use HTTPS in production.

## Next layers
- streaming answers
- persistent conversation history
- memory
- voice
- image/file input
- multi-agent orchestration
- tool/action permissions
- source cards
- production auth, rate limits and logging
