package com.bankai

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject
import kotlin.concurrent.thread
import android.graphics.drawable.GradientDrawable

class MainActivity : android.app.Activity() {
    private lateinit var messages: LinearLayout
    private lateinit var input: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUI()
    }

    private fun bg(color: Int, radius: Float = 24f): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius }

    private fun buildUI() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 32, 24, 18)
            setBackgroundColor(Color.rgb(9,10,16))
        }

        val title = TextView(this).apply {
            text = "BANKAI"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        root.addView(title, LinearLayout.LayoutParams(-1, 70))

        val sub = TextView(this).apply {
            text = "Ask anything. Let's figure it out."
            textSize = 15f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        root.addView(sub, LinearLayout.LayoutParams(-1, 45))

        messages = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 20, 0, 10)
        }
        val scroll = ScrollView(this).apply { addView(messages) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        input = EditText(this).apply {
            hint = "Message BANKAI..."
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            setSingleLine(false)
            background = bg(Color.rgb(24,26,35), 40f)
            setPadding(24, 14, 18, 14)
        }
        row.addView(input, LinearLayout.LayoutParams(0, 62, 1f))

        val send = Button(this).apply {
            text = "➤"
            textSize = 22f
            setTextColor(Color.WHITE)
            background = bg(Color.rgb(65,70,120), 40f)
            setOnClickListener { sendMessage() }
        }
        val sp = LinearLayout.LayoutParams(62,62); sp.setMargins(10,0,0,0)
        row.addView(send, sp)
        root.addView(row)

        setContentView(root)
    }

    private fun addBubble(text: String, user: Boolean) {
        val tv = TextView(this).apply {
            this.text = text
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(20,16,20,16)
            background = bg(if (user) Color.rgb(45,48,70) else Color.rgb(22,24,32), 28f)
        }
        val p = LinearLayout.LayoutParams(-1, -2)
        p.setMargins(0, 8, 0, 8)
        messages.addView(tv, p)
    }

    private fun sendMessage() {
        val q = input.text.toString().trim()
        if (q.isEmpty()) return
        addBubble(q, true)
        input.setText("")
        addBubble("BANKAI is thinking…", false)
        thread {
            val answer = try {
                val conn = URL("http://10.0.2.2:3000/chat").openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                conn.outputStream.use { it.write(JSONObject().put("message", q).toString().toByteArray()) }
                val body = conn.inputStream.bufferedReader().readText()
                JSONObject(body).optString("answer", "BANKAI could not get a response.")
            } catch (e: Exception) {
                "Backend not connected yet. Start the BANKAI server on your computer, then try again."
            }
            runOnUiThread {
                if (messages.childCount > 0) messages.removeViewAt(messages.childCount - 1)
                addBubble(answer, false)
            }
        }
    }
}
