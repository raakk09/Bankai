plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android { namespace = "com.bankai"; compileSdk = 35
    defaultConfig { applicationId = "com.bankai"; minSdk = 24; targetSdk = 35; versionCode = 1; versionName = "0.1" }
}
